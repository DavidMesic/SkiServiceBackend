﻿namespace SkiServiceAPI.Models
{
    public class AccountLogin
    {
        public string Email { get; set; }

        public string PasswortHash { get; set; }
    }
}
